<?php
namespace Easy\Checkout\Controller\Account;

class EmailCheck extends \Magento\Framework\App\Action\Action
{
	public function __construct(
	    \Magento\Framework\App\Action\Context $context,
	    \Magento\Framework\Controller\Result\JsonFactory $resultJsonFactory,
      \Magento\Customer\Api\CustomerRepositoryInterface $customerRepositoryInterface
	) {
	    parent::__construct($context);
	    $this->resultJsonFactory = $resultJsonFactory;
      $this->_customerRepositoryInterface = $customerRepositoryInterface;
	}

 public function execute()
    {
        $available = 0;
        $post = $this->getRequest()->getPostValue();
        $customer_email = $post['email'];
        try {
          if ($this->_customerRepositoryInterface->get($customer_email, $websiteId = null)) {
            $available = 0;
          }else {
            $available = 1;
          }
        } catch (\Exception $e) {
          $available = 1;
        }

        $resultJson = $this->resultJsonFactory->create();
        $success = true;
        return $resultJson->setData([
            'data' => $available,
            'success' => $success
        ]);
    }
  }
