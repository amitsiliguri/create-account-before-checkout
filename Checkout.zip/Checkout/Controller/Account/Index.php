<?php

namespace Easy\Checkout\Controller\Account;

use Magento\Framework\App\Action\Action;
use Magento\Framework\App\Action\Context;
use Magento\Framework\App\ResponseInterface;
use Magento\Framework\View\Result\PageFactory;
use Magento\Customer\Model\Session;
use Magento\Checkout\Model\Cart;

class Index extends Action {
    /**
     * @var PageFactory
     */
    private $pageFactory;

    /**
     * Index constructor.
     * @param Context $context
     * @param PageFactory $pageFactory
     */
    public function __construct(
        Context $context,
        PageFactory $pageFactory,
        Session $session,
        Cart $cartData
    )
    {
        parent::__construct($context);
        $this->pageFactory = $pageFactory;
        $this->_customerSession = $session;
        $this->_cartData = $cartData;
    }
    /**
     * Execute action based on request and return result
     *
     * Note: Request will be added as operation argument in future
     *
     * @return \Magento\Framework\Controller\ResultInterface|ResponseInterface
     * @throws \Magento\Framework\Exception\NotFoundException
     */
    public function execute()
    {
      $totalItems = $this->_cartData->getQuote()->getItemsCount();
      if ($totalItems > 0) {
        if ($this->_customerSession->isLoggedIn()) {
          return $this->resultRedirectFactory->create()->setPath('checkout');
        } else {
          return $this->pageFactory->create();
        }
      }else {
        return $this->resultRedirectFactory->create()->setPath('checkout/cart');
      }
    }
}
