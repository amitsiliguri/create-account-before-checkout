<?php
namespace Easy\Checkout\Plugin\Checkout\Controller\Index;
use Magento\Customer\Model\Session;
use Magento\Checkout\Helper\Data;
use Magento\Framework\Message\ManagerInterface;
use Magento\Framework\Controller\Result\RedirectFactory;
use Magento\Checkout\Model\Session as CheckoutSession;
class Index
{
    public function __construct(
        Session $session,
        Data $checkoutHelper,
        ManagerInterface $messageManager,
        RedirectFactory $resultRedirectFactory,
        CheckoutSession $_checkoutSession
    )
    {
        $this->_customerSession = $session;
        $this->_checkoutHelper = $checkoutHelper;
        $this->_messageManager = $messageManager;
        $this->resultRedirectFactory = $resultRedirectFactory;
        $this->_checkoutSession = $_checkoutSession;
    }
    public function aroundExecute(
    	\Magento\Checkout\Controller\Index\Index $subject,
      \Closure $proceed
    ) {

      if ($this->_customerSession->isLoggedIn() ) {
        return $proceed();
      }else {
        $cartData = $this->_checkoutSession->getQuote()->getAllVisibleItems();
        if (count($cartData) > 0) {
          return $this->resultRedirectFactory->create()->setPath('checkout/account');
        }else {
          return $this->resultRedirectFactory->create()->setPath('checkout/cart');
        }
      }
    }
}
