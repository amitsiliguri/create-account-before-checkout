<?php

namespace Easy\Checkout\Plugin\Customer\Model\Account;

use Magento\Customer\Model\Account\Redirect;
use Magento\Framework\UrlInterface;
use Magento\Framework\Controller\ResultFactory;

class RedirectPlugin
{
  public function __construct(
    UrlInterface $url,
    ResultFactory $resultFactory
  ) {
      $this->url = $url;
      $this->resultFactory = $resultFactory;
  }

	public function afterGetRedirect(Redirect $subject, $result)
	{
    if (isset($_POST['checkout']) && $_POST['checkout'] == true) {
      $result = $this->resultFactory->create(ResultFactory::TYPE_REDIRECT);
      $result->setUrl($this->url->getUrl('checkout'));
    }
		return $result;
	}
}
