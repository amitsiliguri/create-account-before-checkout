require(["jquery"], function($){

  $(document).on('change', '#emailCheck', function() {
    var email = $('#emailCheck').val();
    if (email.length > 5) {
      if(validateEmail(email)) {
        checkEmailAvaibility(email);
      }
    }
  });

  function validateEmail($email) {
    var emailReg = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
    return emailReg.test( $email );
  }

  function checkEmailAvaibility(email) {
    $('body').trigger('processStart');
    $.ajax({
       url : 'http://localhost/magento/m233/checkout/account/emailcheck',
       type : 'POST',
       data: {
         email: email
       },
       dataType:'json',
       success : function(data) {
         $('body').trigger('processStop');
         var available =data.data;
         if (available == 1) {
           $("#email_address").val(email);
           $("#easy_checkout_login_form").css("display", "none");
           $("#easy_checkout_register_form").css("display", "block");
         }else if (available == 0) {
           $("#email").val(email);
           $("#easy_checkout_login_form").css("display", "block");
           $("#easy_checkout_register_form").css("display", "none");
         }else {
           $("#easy_checkout_login_form").css("display", "none");
           $("#easy_checkout_register_form").css("display", "none");
         }
       },
       error : function(request,error)
       {
         $("#easy_checkout_login_form").css("display", "block");
         $("#easy_checkout_register_form").css("display", "none");
         $('body').trigger('processStop');
       }
   });
  }
});
